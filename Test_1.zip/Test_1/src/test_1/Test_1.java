/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package test_1;

/**
 *
 * @author Benjamin
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Test_1 extends JFrame {

    private JTextField[] nameFields = new JTextField[5];
    private JTextField[] ageFields = new JTextField[5];
    
    private JLabel resultLabel;

    public Test_1() {
        setTitle("Family Age Calculator");
        setSize(80, 80);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 2));

        for (int i = 0; i < 5; i++) {
            add(new JLabel("Name" + (i + 1) + ":"));
            nameFields[i] = new JTextField();
            add(nameFields[i]);

            add(new JLabel("Age" + (i + 1) + ":"));
            ageFields[i] = new JTextField();
            add(ageFields[i]);
        }

        JButton printButton = new JButton("Print");
        add(printButton);

        resultLabel = new JLabel();
        add(resultLabel);

        printButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateAges();
            }
        });
    }

    private void calculateAges() {
        int totalAge = 0;
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < 5; i++) {
            String name = nameFields[i].getText();
            int age = Integer.parseInt(ageFields[i].getText());
            totalAge += age;
            result.append(name).append(" is ").append(age).append(" years old.\n");
        }

        double averageAge = totalAge / 5.0;
        result.append("\nTotal Age: ").append(totalAge);
        result.append("\nAverage Age: ").append(averageAge);

        if (averageAge > 60) {
            result.append("\nThe family is mature.");
        } else {
            result.append("\nIt's young.");
        }

        resultLabel.setText("<html>" + result.toString().replace("\n", "<br>") + "</html>");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Test_1 frame = new Test_1();
            frame.setVisible(true);
        });
    }
}